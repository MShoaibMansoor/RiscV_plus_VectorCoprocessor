//=====================================================================
// rv32i_core.sv
// Synthesizable RV32I single-cycle core, plus instruction/data SRAM.
// Harvard-style: separate instruction fetch port and data port.
// Data port is a generic bus (addr/wdata/we/byte_en/rdata) so it can
// be routed either to data_sram or to a memory-mapped peripheral
// (see soc_top.sv further down) by an external address decoder.
//=====================================================================

// ---------------- Instruction memory ----------------
module instr_sram #(
    parameter DEPTH_WORDS = 1024   // 4KB
)(
    input  logic        clk,
    input  logic [31:0] addr,      // byte address, PC
    output logic [31:0] rdata
);
    logic [31:0] mem [0:DEPTH_WORDS-1];
    // initial $readmemh("program.hex", mem);   // load your test program
    assign rdata = mem[addr[31:2]];             // combinational fetch
endmodule


// ---------------- Data memory ----------------
module data_sram #(
    parameter DEPTH_WORDS = 1024   // 4KB
)(
    input  logic        clk,
    input  logic         we,
    input  logic [3:0]   byte_en,
    input  logic [31:0]  addr,     // byte address
    input  logic [31:0]  wdata,
    output logic [31:0]  rdata
);
    logic [31:0] mem [0:DEPTH_WORDS-1];
    assign rdata = mem[addr[31:2]];             // combinational read

    always_ff @(posedge clk) begin
        if (we) begin
            if (byte_en[0]) mem[addr[31:2]][7:0]   <= wdata[7:0];
            if (byte_en[1]) mem[addr[31:2]][15:8]  <= wdata[15:8];
            if (byte_en[2]) mem[addr[31:2]][23:16] <= wdata[23:16];
            if (byte_en[3]) mem[addr[31:2]][31:24] <= wdata[31:24];
        end
    end
endmodule


// ---------------- Register file ----------------
module regfile (
    input  logic        clk,
    input  logic        we,
    input  logic [4:0]  ra1, ra2, wa,
    input  logic [31:0] wd,
    output logic [31:0] rd1, rd2
);
    logic [31:0] regs [1:31];
    assign rd1 = (ra1 == 5'd0) ? 32'd0 : regs[ra1];
    assign rd2 = (ra2 == 5'd0) ? 32'd0 : regs[ra2];

    always_ff @(posedge clk) begin
        if (we && wa != 5'd0) regs[wa] <= wd;
    end
endmodule


// ---------------- ALU ----------------
module alu (
    input  logic [31:0] a, b,
    input  logic [3:0]  op,
    output logic [31:0] y
);
    always_comb begin
        case (op)
            4'b0000: y = a + b;                                        // ADD
            4'b1000: y = a - b;                                        // SUB
            4'b0111: y = a & b;                                        // AND
            4'b0110: y = a | b;                                        // OR
            4'b0100: y = a ^ b;                                        // XOR
            4'b0001: y = a << b[4:0];                                  // SLL
            4'b0101: y = a >> b[4:0];                                  // SRL
            4'b1101: y = $signed(a) >>> b[4:0];                        // SRA
            4'b0010: y = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;    // SLT
            4'b0011: y = (a < b) ? 32'd1 : 32'd0;                      // SLTU
            default: y = 32'd0;
        endcase
    end
endmodule


// ---------------- RV32I single-cycle core ----------------
module rv32i_core (
    input  logic        clk,
    input  logic        rst_n,

    output logic [31:0] imem_addr,
    input  logic [31:0] imem_rdata,

    output logic [31:0] dmem_addr,
    output logic [31:0] dmem_wdata,
    output logic        dmem_we,
    output logic [3:0]  dmem_byte_en,
    input  logic [31:0] dmem_rdata
);
    // opcode map
    localparam OP_RTYPE  = 7'b0110011;
    localparam OP_ITYPE  = 7'b0010011;
    localparam OP_LOAD   = 7'b0000011;
    localparam OP_STORE  = 7'b0100011;
    localparam OP_BRANCH = 7'b1100011;
    localparam OP_JAL    = 7'b1101111;
    localparam OP_JALR   = 7'b1100111;
    localparam OP_LUI    = 7'b0110111;
    localparam OP_AUIPC  = 7'b0010111;

    logic [31:0] pc, pc_next, pc_plus4, pc_target;
    logic [31:0] instr;
    logic [6:0]  opcode;
    logic [4:0]  rd, rs1, rs2;
    logic [2:0]  funct3;
    logic [6:0]  funct7;
    logic [31:0] imm;
    logic [31:0] rdata1, rdata2, wb_data;
    logic [31:0] alu_a_in, alu_b_in, alu_y;
    logic [3:0]  alu_op;

    logic reg_we, alu_src, mem_we, mem_to_reg, branch, jump, jalr, lui_sel, auipc_sel;
    logic branch_cond;

    assign instr  = imem_rdata;
    assign opcode = instr[6:0];
    assign rd     = instr[11:7];
    assign funct3 = instr[14:12];
    assign rs1    = instr[19:15];
    assign rs2    = instr[24:20];
    assign funct7 = instr[31:25];

    // ---- immediate generator ----
    always_comb begin
        case (opcode)
            OP_ITYPE, OP_LOAD, OP_JALR:
                imm = {{20{instr[31]}}, instr[31:20]};
            OP_STORE:
                imm = {{20{instr[31]}}, instr[31:25], instr[11:7]};
            OP_BRANCH:
                imm = {{19{instr[31]}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0};
            OP_LUI, OP_AUIPC:
                imm = {instr[31:12], 12'b0};
            OP_JAL:
                imm = {{11{instr[31]}}, instr[31], instr[19:12], instr[20], instr[30:21], 1'b0};
            default:
                imm = 32'd0;
        endcase
    end

    // ---- control unit ----
    always_comb begin
        reg_we = 0; alu_src = 0; mem_we = 0; mem_to_reg = 0;
        branch = 0; jump = 0; jalr = 0; lui_sel = 0; auipc_sel = 0;
        alu_op = 4'b0000;

        case (opcode)
            OP_RTYPE: begin
                reg_we = 1;
                case ({funct7[5], funct3})
                    4'b0000: alu_op = 4'b0000; // ADD
                    4'b1000: alu_op = 4'b1000; // SUB
                    4'b0111: alu_op = 4'b0111; // AND
                    4'b0110: alu_op = 4'b0110; // OR
                    4'b0100: alu_op = 4'b0100; // XOR
                    4'b0001: alu_op = 4'b0001; // SLL
                    4'b0101: alu_op = 4'b0101; // SRL
                    4'b1101: alu_op = 4'b1101; // SRA
                    4'b0010: alu_op = 4'b0010; // SLT
                    4'b0011: alu_op = 4'b0011; // SLTU
                    default: alu_op = 4'b0000;
                endcase
            end
            OP_ITYPE: begin
                reg_we = 1; alu_src = 1;
                case (funct3)
                    3'b000: alu_op = 4'b0000; // ADDI
                    3'b111: alu_op = 4'b0111; // ANDI
                    3'b110: alu_op = 4'b0110; // ORI
                    3'b100: alu_op = 4'b0100; // XORI
                    3'b001: alu_op = 4'b0001; // SLLI
                    3'b101: alu_op = funct7[5] ? 4'b1101 : 4'b0101; // SRAI/SRLI
                    3'b010: alu_op = 4'b0010; // SLTI
                    3'b011: alu_op = 4'b0011; // SLTIU
                    default: alu_op = 4'b0000;
                endcase
            end
            OP_LOAD:   begin reg_we = 1; alu_src = 1; mem_to_reg = 1; alu_op = 4'b0000; end
            OP_STORE:  begin alu_src = 1; mem_we = 1; alu_op = 4'b0000; end
            OP_BRANCH: begin branch = 1; end
            OP_JAL:    begin reg_we = 1; jump = 1; end
            OP_JALR:   begin reg_we = 1; jump = 1; jalr = 1; alu_src = 1; alu_op = 4'b0000; end
            OP_LUI:    begin reg_we = 1; lui_sel = 1; end
            OP_AUIPC:  begin reg_we = 1; auipc_sel = 1; end
            default: ;
        endcase
    end

    // ---- branch comparator ----
    always_comb begin
        case (funct3)
            3'b000:  branch_cond = (rdata1 == rdata2);                         // BEQ
            3'b001:  branch_cond = (rdata1 != rdata2);                         // BNE
            3'b100:  branch_cond = ($signed(rdata1) <  $signed(rdata2));       // BLT
            3'b101:  branch_cond = ($signed(rdata1) >= $signed(rdata2));       // BGE
            3'b110:  branch_cond = (rdata1 <  rdata2);                        // BLTU
            3'b111:  branch_cond = (rdata1 >= rdata2);                        // BGEU
            default: branch_cond = 1'b0;
        endcase
    end

    // ---- register file + ALU ----
    regfile u_rf (.clk(clk), .we(reg_we), .ra1(rs1), .ra2(rs2),
                  .wa(rd), .wd(wb_data), .rd1(rdata1), .rd2(rdata2));

    assign alu_a_in = auipc_sel ? pc : rdata1;
    assign alu_b_in = alu_src   ? imm : rdata2;

    alu u_alu (.a(alu_a_in), .b(alu_b_in), .op(alu_op), .y(alu_y));

    // ---- PC logic ----
    assign pc_plus4  = pc + 32'd4;
    assign pc_target = jalr ? ((rdata1 + imm) & ~32'd1) : (pc + imm);

    always_comb begin
        pc_next = pc_plus4;
        if (jump) pc_next = pc_target;
        else if (branch && branch_cond) pc_next = pc_target;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) pc <= 32'd0;
        else        pc <= pc_next;
    end
    assign imem_addr = pc;

    // ---- load data alignment / sign extension ----
    logic [1:0]  addr_lsb;
    logic [7:0]  load_byte;
    logic [15:0] load_half;
    logic [31:0] load_data;

    assign addr_lsb = alu_y[1:0];

    always_comb begin
        case (addr_lsb)
            2'b00: load_byte = dmem_rdata[7:0];
            2'b01: load_byte = dmem_rdata[15:8];
            2'b10: load_byte = dmem_rdata[23:16];
            2'b11: load_byte = dmem_rdata[31:24];
        endcase
        load_half = addr_lsb[1] ? dmem_rdata[31:16] : dmem_rdata[15:0];

        case (funct3)
            3'b000:  load_data = {{24{load_byte[7]}}, load_byte};   // LB
            3'b001:  load_data = {{16{load_half[15]}}, load_half};  // LH
            3'b010:  load_data = dmem_rdata;                        // LW
            3'b100:  load_data = {24'd0, load_byte};                // LBU
            3'b101:  load_data = {16'd0, load_half};                // LHU
            default: load_data = dmem_rdata;
        endcase
    end

    // ---- store data alignment / byte enables ----
    always_comb begin
        dmem_byte_en = 4'b0000;
        dmem_wdata   = 32'd0;
        case (funct3)
            3'b000: begin // SB
                case (addr_lsb)
                    2'b00: begin dmem_byte_en = 4'b0001; dmem_wdata = {24'd0, rdata2[7:0]}; end
                    2'b01: begin dmem_byte_en = 4'b0010; dmem_wdata = {16'd0, rdata2[7:0], 8'd0}; end
                    2'b10: begin dmem_byte_en = 4'b0100; dmem_wdata = {8'd0, rdata2[7:0], 16'd0}; end
                    2'b11: begin dmem_byte_en = 4'b1000; dmem_wdata = {rdata2[7:0], 24'd0}; end
                endcase
            end
            3'b001: begin // SH
                if (addr_lsb[1]) begin dmem_byte_en = 4'b1100; dmem_wdata = {rdata2[15:0], 16'd0}; end
                else             begin dmem_byte_en = 4'b0011; dmem_wdata = {16'd0, rdata2[15:0]}; end
            end
            3'b010: begin dmem_byte_en = 4'b1111; dmem_wdata = rdata2; end // SW
            default: ;
        endcase
    end

    assign dmem_addr = alu_y;
    assign dmem_we   = mem_we;

    // ---- writeback mux ----
    always_comb begin
        if      (mem_to_reg) wb_data = load_data;
        else if (lui_sel)    wb_data = imm;
        else if (auipc_sel)  wb_data = pc + imm;
        else if (jump)       wb_data = pc_plus4;
        else                 wb_data = alu_y;
    end

endmodule