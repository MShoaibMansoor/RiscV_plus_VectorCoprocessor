//=====================================================================
// soc_top.sv
// Integrates rv32i_core + instr_sram + data_sram + vector_coproc.
// Address decode: dmem_addr[31:28]==4'h8 routes to vector coprocessor,
// everything else goes to data_sram.
//=====================================================================
module soc_top;
    logic clk, rst_n;
    logic [31:0] imem_addr, imem_rdata;
    logic [31:0] dmem_addr, dmem_wdata, dmem_rdata;
    logic        dmem_we;
    logic [3:0]  dmem_byte_en;

    logic sel_vec;
    assign sel_vec = (dmem_addr[31:28] == 4'h8);

    logic [31:0] sram_rdata, vec_rdata;
    assign dmem_rdata = sel_vec ? vec_rdata : sram_rdata;

    rv32i_core u_core (
        .clk(clk), .rst_n(rst_n),
        .imem_addr(imem_addr), .imem_rdata(imem_rdata),
        .dmem_addr(dmem_addr), .dmem_wdata(dmem_wdata),
        .dmem_we(dmem_we), .dmem_byte_en(dmem_byte_en),
        .dmem_rdata(dmem_rdata)
    );

    instr_sram u_imem (.clk(clk), .addr(imem_addr), .rdata(imem_rdata));

    data_sram u_dmem (
        .clk(clk), .we(dmem_we & ~sel_vec), .byte_en(dmem_byte_en),
        .addr(dmem_addr), .wdata(dmem_wdata), .rdata(sram_rdata)
    );

    vector_coproc u_vec (
        .clk(clk), .rst_n(rst_n),
        .addr(dmem_addr[11:0]), .wdata(dmem_wdata),
        .wren(dmem_we & sel_vec), .rden(sel_vec), .rdata(vec_rdata)
    );
endmodule