import vec_tb_pkg::*;

module tb_top;
    logic clk = 0;
    always #5 clk = ~clk;

    vec_if vif (clk);

    vector_coproc dut (
        .clk(vif.clk), .rst_n(vif.rst_n),
        .addr(vif.addr), .wdata(vif.wdata), .wren(vif.wren),
        .rden(vif.rden), .rdata(vif.rdata)
    );

    initial begin
        vif.rst_n = 0; vif.wren = 0; vif.rden = 0; vif.addr = 0; vif.wdata = 0;
        repeat (3) @(posedge clk);
        vif.rst_n = 1;

        // ---- Reset test ----
        @(posedge clk);
        vif.addr = 12'h004; vif.rden = 1;
        @(posedge clk);
        if (vif.rdata[1:0] !== 2'b00)
            $display("RESET TEST: FAIL status=%0h", vif.rdata);
        else
            $display("RESET TEST: PASS");
        vif.rden = 0;

        begin
            automatic vec_env env = new(vif);
            env.run();
        end

        $finish;
    end
endmodule