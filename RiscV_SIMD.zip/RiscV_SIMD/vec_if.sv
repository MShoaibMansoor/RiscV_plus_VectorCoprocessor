interface vec_if (input logic clk);
    logic        rst_n;
    logic [11:0] addr;
    logic [31:0] wdata;
    logic        wren;
    logic        rden;
    logic [31:0] rdata;
endinterface