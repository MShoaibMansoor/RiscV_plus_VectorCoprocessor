package vec_tb_pkg;

    class vec_transaction;
        rand bit [2:0]  opcode;
        rand bit [3:0]  vlen;
        rand bit [2:0]  src1_idx, src2_idx, dst_idx;
        rand bit [31:0] src1_data [8];
        rand bit [31:0] src2_data [8];
        bit [31:0]      result_data [8];
        bit             exp_err;
        bit             obs_err;

        constraint c_vlen { vlen inside {[1:8]}; }
        constraint c_op   { opcode inside {[0:3]}; }
        constraint c_idx  { src1_idx != dst_idx; src2_idx != dst_idx; }
    endclass


    class vec_generator;
        mailbox #(vec_transaction) gen2drv;
        function new(mailbox #(vec_transaction) gen2drv);
            this.gen2drv = gen2drv;
        endfunction

        task run();
            vec_transaction t;

            // ---- Directed case 1: ADD, full vlen=8 ----
            t = new(); t.opcode = 0; t.vlen = 8; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 2;
            foreach (t.src1_data[i]) t.src1_data[i] = i + 1;
            foreach (t.src2_data[i]) t.src2_data[i] = 10;
            gen2drv.put(t);

            // ---- Directed case 2: MUL, vlen=4 (partial length) ----
            t = new(); t.opcode = 1; t.vlen = 4; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 3;
            foreach (t.src1_data[i]) t.src1_data[i] = i + 2;
            foreach (t.src2_data[i]) t.src2_data[i] = 3;
            gen2drv.put(t);

            // ---- Directed case 3: CMP, vlen=8 ----
            t = new(); t.opcode = 2; t.vlen = 8; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 4;
            foreach (t.src1_data[i]) t.src1_data[i] = i;
            foreach (t.src2_data[i]) t.src2_data[i] = 4;
            gen2drv.put(t);

            // ---- Directed case 4: REDSUM, vlen=8 ----
            t = new(); t.opcode = 3; t.vlen = 8; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 5;
            foreach (t.src1_data[i]) t.src1_data[i] = 1;
            gen2drv.put(t);

            // ---- Error case 1: invalid opcode ----
            t = new(); t.opcode = 6; t.vlen = 8; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 6;
            gen2drv.put(t);

            // ---- Error case 2: invalid vlen = 0 ----
            t = new(); t.opcode = 0; t.vlen = 0; t.src1_idx = 0; t.src2_idx = 1; t.dst_idx = 7;
            gen2drv.put(t);

            // ---- Randomized mixed regression ----
            repeat (8) begin
                t = new();
                if (!t.randomize())
                    $error("Randomization failed");
                gen2drv.put(t);
            end
        endtask
    endclass


    class vec_driver;
        virtual vec_if vif;
        mailbox #(vec_transaction) gen2drv;
        mailbox #(vec_transaction) drv2sb;

        function new(virtual vec_if vif, mailbox #(vec_transaction) gen2drv,
                      mailbox #(vec_transaction) drv2sb);
            this.vif = vif; this.gen2drv = gen2drv; this.drv2sb = drv2sb;
        endfunction

        task run();
            vec_transaction t;
            forever begin
                gen2drv.get(t);
                drive(t);
                drv2sb.put(t);
            end
        endtask

        task write_word(bit [11:0] a, bit [31:0] d);
            @(posedge vif.clk);
            vif.addr = a; vif.wdata = d; vif.wren = 1;
            @(posedge vif.clk);
            vif.wren = 0;
        endtask

        task drive(vec_transaction t);
            for (int i = 0; i < 8; i++) begin
                write_word(12'h100 + ((t.src1_idx*8 + i) << 2), t.src1_data[i]);
                write_word(12'h100 + ((t.src2_idx*8 + i) << 2), t.src2_data[i]);
            end
            write_word(12'h000, {16'd0, t.vlen, t.dst_idx, t.src2_idx, t.src1_idx, t.opcode});

            // poll status until done
            forever begin
                @(posedge vif.clk);
                vif.addr = 12'h004; vif.rden = 1;
                @(posedge vif.clk);
                if (vif.rdata[1]) begin
                    vif.rden = 0;
                    break;
                end
            end
        endtask
    endclass


    class vec_monitor;
        virtual vec_if vif;
        mailbox #(vec_transaction) mon2sb;
        bit [2:0] last_op, last_s1, last_s2, last_dst;
        bit [3:0] last_len;

        function new(virtual vec_if vif, mailbox #(vec_transaction) mon2sb);
            this.vif = vif; this.mon2sb = mon2sb;
        endfunction

        task run();
            forever begin
                @(posedge vif.clk);
                if (vif.wren && vif.addr == 12'h000) begin
                    last_op  = vif.wdata[2:0];
                    last_s1  = vif.wdata[5:3];
                    last_s2  = vif.wdata[8:6];
                    last_dst = vif.wdata[11:9];
                    last_len = vif.wdata[15:12];
                end
                if (vif.rden && vif.addr == 12'h004 && vif.rdata[1]) begin
                    automatic vec_transaction obs = new();
                    obs.opcode = last_op; obs.vlen = last_len;
                    obs.src1_idx = last_s1; obs.src2_idx = last_s2; obs.dst_idx = last_dst;
                    obs.obs_err = vif.rdata[2];

                    for (int w = 0; w < 8; w++) begin
                        @(posedge vif.clk);
                        vif.addr = 12'h100 + ((last_dst*8 + w) << 2);
                        vif.rden = 1;
                        @(posedge vif.clk);
                        obs.result_data[w] = vif.rdata;
                    end
                    vif.rden = 0;
                    mon2sb.put(obs);
                end
            end
        endtask
    endclass


    class vec_scoreboard;
        mailbox #(vec_transaction) drv2sb;
        mailbox #(vec_transaction) mon2sb;
        int pass_cnt = 0, fail_cnt = 0;

        function new(mailbox #(vec_transaction) drv2sb, mailbox #(vec_transaction) mon2sb);
            this.drv2sb = drv2sb; this.mon2sb = mon2sb;
        endfunction

        function automatic void ref_model(vec_transaction t);
            bit [31:0] exp [8];
            bit exp_err = 1'b0;

            if (t.vlen == 0 || t.vlen > 8 || t.opcode > 3) begin
                exp_err = 1'b1;
            end else begin
                for (int i = 0; i < 8; i++) exp[i] = 32'd0;
                case (t.opcode)
                    3'd0: for (int i = 0; i < t.vlen; i++) exp[i] = t.src1_data[i] + t.src2_data[i];
                    3'd1: for (int i = 0; i < t.vlen; i++) exp[i] = t.src1_data[i] * t.src2_data[i];
                    3'd2: for (int i = 0; i < t.vlen; i++) exp[i] = (t.src1_data[i] > t.src2_data[i]) ? 32'd1 : 32'd0;
                    3'd3: begin
                        bit [31:0] sum = 32'd0;
                        for (int i = 0; i < t.vlen; i++) sum += t.src1_data[i];
                        exp[0] = sum;
                    end
                endcase
            end
            t.result_data = exp;
            t.exp_err = exp_err;
        endfunction

        task run();
            vec_transaction e, o;
            forever begin
                drv2sb.get(e);
                ref_model(e);
                mon2sb.get(o);
                compare(e, o);
            end
        endtask

        task compare(vec_transaction e, vec_transaction o);
            bit ok = 1'b1;
            if (e.exp_err !== o.obs_err) ok = 1'b0;
            if (!e.exp_err)
                for (int i = 0; i < 8; i++)
                    if (e.result_data[i] !== o.result_data[i]) ok = 1'b0;

            if (ok) begin
                pass_cnt++;
                $display("[%0t] PASS op=%0d vlen=%0d", $time, e.opcode, e.vlen);
            end else begin
                fail_cnt++;
                $display("[%0t] FAIL op=%0d vlen=%0d exp_err=%0b obs_err=%0b",
                          $time, e.opcode, e.vlen, e.exp_err, o.obs_err);
            end
        endtask
    endclass


    class vec_env;
        virtual vec_if vif;
        mailbox #(vec_transaction) gen2drv, drv2sb, mon2sb;
        vec_generator gen;
        vec_driver    drv;
        vec_monitor   mon;
        vec_scoreboard sb;

        function new(virtual vec_if vif);
            this.vif = vif;
            gen2drv = new(); drv2sb = new(); mon2sb = new();
            gen = new(gen2drv);
            drv = new(vif, gen2drv, drv2sb);
            mon = new(vif, mon2sb);
            sb  = new(drv2sb, mon2sb);
        endfunction

        task run();
            fork
                drv.run();
                mon.run();
                sb.run();
            join_none
            gen.run();
            #2000;
            $display("==== SUMMARY: PASS=%0d FAIL=%0d ====", sb.pass_cnt, sb.fail_cnt);
        endtask
    endclass

endpackage