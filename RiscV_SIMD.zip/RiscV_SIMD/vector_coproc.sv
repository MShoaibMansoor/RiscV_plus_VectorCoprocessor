//=====================================================================
// vector_coproc.sv
// Memory-mapped vector/SIMD coprocessor.
// VLEN = 256 bits = 8 x 32-bit words per vector register. 8 vector regs.
//
// Local register map (12-bit byte address, mapped by soc_top at 0x8000_0000):
//   0x000            VCMD    (W)  : [2:0]=opcode [5:3]=src1 [8:6]=src2
//                                   [11:9]=dst [15:12]=vlen(1-8). Any write triggers start.
//   0x004            VSTATUS (R)  : bit0=busy bit1=done bit2=error
//   0x100 - 0x1FF     VREG window (R/W) : 8 regs x 8 words x 4B = 256B
//                     word addr index = (addr-0x100)>>2 ; reg=index[5:3] word=index[2:0]
//
// Opcodes: 000=ADD  001=MUL  010=CMP(greater-than mask)  011=REDSUM(reduction)
// Anything else, or vlen==0, or vlen>8  -> ERROR flagged, no data written.
//
// Operand loading is done directly through the VREG window (ordinary
// memory-mapped stores from the CPU, or directly from the testbench) --
// this *is* the "vector load/store" path, avoiding a separate bus-master
// LSU and the arbitration logic that would otherwise be needed.
//=====================================================================

module vector_coproc #(
    parameter VLEN_WORDS = 8,
    parameter VREG_NUM   = 8
)(
    input  logic        clk,
    input  logic        rst_n,

    input  logic [11:0] addr,
    input  logic [31:0] wdata,
    input  logic        wren,
    input  logic        rden,
    output logic [31:0] rdata
);
    localparam CMD_OFFSET    = 12'h000;
    localparam STATUS_OFFSET = 12'h004;
    localparam VREG_BASE     = 12'h100;
    localparam VREG_TOP      = 12'h1FF;

    localparam OP_ADD    = 3'd0;
    localparam OP_MUL    = 3'd1;
    localparam OP_CMP    = 3'd2;
    localparam OP_REDSUM = 3'd3;

    typedef enum logic [1:0] {S_IDLE, S_RUN} state_t;
    state_t state;

    logic [31:0] vreg_file [0:VREG_NUM-1][0:VLEN_WORDS-1];

    logic [2:0] opcode_r, src1_r, src2_r, dst_r;
    logic [3:0] vlen_r;
    logic [2:0] elem_cnt;
    logic [31:0] accum;

    logic busy, done, err;
    logic cmd_start;
    logic op_valid, vlen_valid;

    assign op_valid   = (wdata[2:0] <= OP_REDSUM);
    assign vlen_valid = (wdata[15:12] >= 4'd1) && (wdata[15:12] <= VLEN_WORDS[3:0]);

    // address decode helpers for the VREG window
    logic in_vreg_window;
    logic [5:0] vreg_index;
    logic [2:0] sel_reg, sel_word;

    assign in_vreg_window = (addr >= VREG_BASE) && (addr <= VREG_TOP);
    assign vreg_index = (addr - VREG_BASE) >> 2;
    assign sel_reg    = vreg_index[5:3];
    assign sel_word   = vreg_index[2:0];


    // ---------------- write path: command decode + start pulse ----------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cmd_start <= 1'b0;
            opcode_r <= 0; src1_r <= 0; src2_r <= 0; dst_r <= 0; vlen_r <= 0;
        end else begin
            cmd_start <= 1'b0;
            if (wren && addr == CMD_OFFSET) begin
                opcode_r  <= wdata[2:0];
                src1_r    <= wdata[5:3];
                src2_r    <= wdata[8:6];
                dst_r     <= wdata[11:9];
                vlen_r    <= wdata[15:12];
                cmd_start <= 1'b1;
            end
        end
    end


//    // ---------------- FSM: busy/done/error + element-wise compute ----------------
//    always_ff @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            state <= S_IDLE;
//            busy <= 1'b0; done <= 1'b0; err <= 1'b0;
//            elem_cnt <= 3'd0; accum <= 32'd0;
//        end else begin
//            case (state)
//                S_IDLE: begin
//                    if (cmd_start) begin
//                        done <= 1'b0;
//                        if (!op_valid || !vlen_valid) begin
//                            err  <= 1'b1;
//                            done <= 1'b1;
//                            busy <= 1'b0;
//                            // state stays S_IDLE -- no data written on error
//                        end else begin
//                            err      <= 1'b0;
//                            busy     <= 1'b1;
//                            elem_cnt <= 3'd0;
//                            accum    <= 32'd0;
//                            state    <= S_RUN;
//                        end
//                    end
//                end
//
//                S_RUN: begin
//                    unique case (opcode_r)
//                        OP_ADD:    vreg_file[dst_r][elem_cnt] <= vreg_file[src1_r][elem_cnt] + vreg_file[src2_r][elem_cnt];
//                        OP_MUL:    vreg_file[dst_r][elem_cnt] <= vreg_file[src1_r][elem_cnt] * vreg_file[src2_r][elem_cnt];
//                        OP_CMP:    vreg_file[dst_r][elem_cnt] <= (vreg_file[src1_r][elem_cnt] > vreg_file[src2_r][elem_cnt]) ? 32'd1 : 32'd0;
//                        OP_REDSUM: accum <= accum + vreg_file[src1_r][elem_cnt];
//                        default: ;
//                    endcase
//
//                    if (elem_cnt == vlen_r - 1) begin
//                        if (opcode_r == OP_REDSUM)
//                            vreg_file[dst_r][0] <= accum + vreg_file[src1_r][elem_cnt];
//                        busy  <= 1'b0;
//                        done  <= 1'b1;
//                        state <= S_IDLE;
//                    end else begin
//                        elem_cnt <= elem_cnt + 3'd1;
//                    end
//                end
//                default: state <= S_IDLE;
//            endcase
//        end
//    end





    // ---------------- FSM: busy/done/error + element-wise compute
    //                   + operand-load write path (single merged driver
    //                   of vreg_file to satisfy synthesis/sim single-
    //                   process-per-signal rules) ----------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= S_IDLE;
            busy     <= 1'b0;
            done     <= 1'b0;
            err      <= 1'b0;
            elem_cnt <= 3'd0;
            accum    <= 32'd0;
        end else begin
            case (state)
                S_IDLE: begin
                    // operand loads only accepted while idle
                    if (wren && in_vreg_window) begin
                        vreg_file[sel_reg][sel_word] <= wdata;
                    end

                    if (cmd_start) begin
                        done <= 1'b0;
                        if (!op_valid || !vlen_valid) begin
                            err  <= 1'b1;
                            done <= 1'b1;
                            busy <= 1'b0;
                            // state stays S_IDLE -- no data written on error
                        end else begin
                            err      <= 1'b0;
                            busy     <= 1'b1;
                            elem_cnt <= 3'd0;
                            accum    <= 32'd0;
                            state    <= S_RUN;
                        end
                    end
                end

                S_RUN: begin
                    unique case (opcode_r)
                        OP_ADD:    vreg_file[dst_r][elem_cnt] <= vreg_file[src1_r][elem_cnt] + vreg_file[src2_r][elem_cnt];
                        OP_MUL:    vreg_file[dst_r][elem_cnt] <= vreg_file[src1_r][elem_cnt] * vreg_file[src2_r][elem_cnt];
                        OP_CMP:    vreg_file[dst_r][elem_cnt] <= (vreg_file[src1_r][elem_cnt] > vreg_file[src2_r][elem_cnt]) ? 32'd1 : 32'd0;
                        OP_REDSUM: accum <= accum + vreg_file[src1_r][elem_cnt];
                        default: ;
                    endcase

                    if (elem_cnt == vlen_r - 1) begin
                        if (opcode_r == OP_REDSUM)
                            vreg_file[dst_r][0] <= accum + vreg_file[src1_r][elem_cnt];
                        busy  <= 1'b0;
                        done  <= 1'b1;
                        state <= S_IDLE;
                    end else begin
                        elem_cnt <= elem_cnt + 3'd1;
                    end
                end

                default: state <= S_IDLE;
            endcase
        end
    end



//    // ---------------- CPU/testbench write path into the VREG window ----------------
//    // Only allowed while the unit is idle (not busy), same clocked block
//    // as the FSM's own writes above would conflict, so this is a SEPARATE
//    // always_ff guarded to never overlap: FSM only writes during S_RUN,
//    // this only writes during S_IDLE/not-busy.
//    always_ff @(posedge clk) begin
//        if (wren && in_vreg_window && !busy) begin
//            vreg_file[sel_reg][sel_word] <= wdata;
//        end
//    end



    // ---------------- read path ----------------
    always_comb begin
        rdata = 32'd0;
        if (rden) begin
            if (addr == STATUS_OFFSET)
                rdata = {29'd0, err, done, busy};
            else if (in_vreg_window)
                rdata = vreg_file[sel_reg][sel_word];
        end
    end

endmodule