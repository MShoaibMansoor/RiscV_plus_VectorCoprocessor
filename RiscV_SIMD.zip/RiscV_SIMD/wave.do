onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -radix hexadecimal /tb_top/clk
add wave -noupdate -radix hexadecimal /tb_top/vif/clk
add wave -noupdate -radix hexadecimal /tb_top/vif/rst_n
add wave -noupdate -radix hexadecimal /tb_top/vif/addr
add wave -noupdate -radix hexadecimal /tb_top/vif/wdata
add wave -noupdate -radix hexadecimal /tb_top/vif/wren
add wave -noupdate -radix hexadecimal /tb_top/vif/rden
add wave -noupdate -radix hexadecimal /tb_top/vif/rdata
add wave -noupdate -radix hexadecimal /tb_top/dut/clk
add wave -noupdate -radix hexadecimal /tb_top/dut/rst_n
add wave -noupdate -radix hexadecimal /tb_top/dut/addr
add wave -noupdate -radix hexadecimal /tb_top/dut/wdata
add wave -noupdate -radix hexadecimal /tb_top/dut/wren
add wave -noupdate -radix hexadecimal /tb_top/dut/rden
add wave -noupdate -radix hexadecimal /tb_top/dut/rdata
add wave -noupdate -radix hexadecimal /tb_top/dut/state
add wave -noupdate -radix hexadecimal /tb_top/dut/opcode_r
add wave -noupdate -radix hexadecimal /tb_top/dut/src1_r
add wave -noupdate -radix hexadecimal /tb_top/dut/src2_r
add wave -noupdate -radix hexadecimal /tb_top/dut/dst_r
add wave -noupdate -radix hexadecimal /tb_top/dut/vlen_r
add wave -noupdate -radix hexadecimal /tb_top/dut/elem_cnt
add wave -noupdate -radix hexadecimal /tb_top/dut/accum
add wave -noupdate -radix hexadecimal /tb_top/dut/busy
add wave -noupdate -radix hexadecimal /tb_top/dut/done
add wave -noupdate -radix hexadecimal /tb_top/dut/err
add wave -noupdate -radix hexadecimal /tb_top/dut/cmd_start
add wave -noupdate -radix hexadecimal /tb_top/dut/op_valid
add wave -noupdate -radix hexadecimal /tb_top/dut/vlen_valid
add wave -noupdate -radix hexadecimal /tb_top/dut/in_vreg_window
add wave -noupdate -radix hexadecimal /tb_top/dut/vreg_index
add wave -noupdate -radix hexadecimal /tb_top/dut/sel_reg
add wave -noupdate -radix hexadecimal /tb_top/dut/sel_word
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {908 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ns} {250 ns}
