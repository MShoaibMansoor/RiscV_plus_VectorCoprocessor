SET MApping Method -sensitive
SET PARAllel Option -threads 1,4 -norelease_license
SET COmpare Options -threads 1,4
SET MUltiplier Implementation boothrca -both
SET UNDEfined Cell black_box -noascend -both
SET HDl Options -unsized_constant_truncate off
SET HDl Options -extract_macro_constraint
ADD SEarch Path ../lib/ -library -both
REAd LIbrary -liberty -both /home/PD5/riscv_pd/custom_vector_pd/synthesis/../lib/slow_vdd1v0_basicCells.lib
REAd DEsign -verilog95 -golden -lastmod -noelab fv/riscv_soc_top/fv_map.v.gz
EXIt -f
