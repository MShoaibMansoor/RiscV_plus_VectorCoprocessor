// Synthesis netlist (golden) vs final Innovus netlist (revised)
set log file pnr_lec.log -replace
read library ../lib/slow_vdd1v0_basicCells.v -verilog -both
read design ../synthesis/outputs/riscv_soc_top_netlist.v -verilog -golden
read design ../physical_design/outputs/riscv_soc_top_pnr.v -verilog -revised
set system mode lec
add compared points -all
compare
report verification
