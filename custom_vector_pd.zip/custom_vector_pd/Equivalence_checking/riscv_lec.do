// Lab 2-1: RTL (golden) vs synthesis netlist (revised)
//   cd Equivalence_checking ; lec -XL -nogui -color -64 -dofile riscv_lec.do
// No DFT in this design -> no SE pin constraint / scan_in / scan_out lines.
set log file riscv_lec.log -replace
read library ../lib/slow_vdd1v0_basicCells.v -verilog -both
add search path ../rtl -design -golden
read design ../rtl/rv32i_core_modules.sv ../rtl/vec_alu.sv ../rtl/vec_regfile.sv \
            ../rtl/vec_coproc.sv ../rtl_pd/pd_imem_rom.sv ../rtl_pd/pd_data_mem_flops.sv \
            ../rtl/riscv_soc_top.sv -systemverilog -golden -root riscv_soc_top
read design ../synthesis/outputs/riscv_soc_top_netlist.v -verilog -revised -root riscv_soc_top
set system mode lec
add compared points -all
compare
report verification
report compare data -class nonequivalent
