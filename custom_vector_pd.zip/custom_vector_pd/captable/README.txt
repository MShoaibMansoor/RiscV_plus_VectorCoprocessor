Copy the files from /home/PD14/counter_design_database_45nm/captable here (see GUIDE.md, Step 0).
