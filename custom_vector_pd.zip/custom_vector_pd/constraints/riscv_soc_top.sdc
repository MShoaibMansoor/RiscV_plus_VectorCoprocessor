# =============================================================================
# riscv_soc_top.sdc - constraints for the complete top level (gpdk045, 45 nm)
# Same style as the lab's constraints_top.sdc, extended for this design.
#   inputs : clk, rst (async, active high)
#   outputs: trap, halted, trap_cause[4:0], rvfi[387:0] (retire trace)
# =============================================================================
create_clock -name clk -period 10 -waveform {0 5} [get_ports "clk"]
set_clock_transition -rise 0.1 [get_clocks "clk"]
set_clock_transition -fall 0.1 [get_clocks "clk"]
set_clock_uncertainty -setup 0.2 [get_clocks "clk"]
set_clock_uncertainty -hold  0.05 [get_clocks "clk"]

set_input_delay  -max 1.0 -clock [get_clocks "clk"] [get_ports "rst"]
set_input_delay  -min 0.2 -clock [get_clocks "clk"] [get_ports "rst"]
set_output_delay -max 1.0 -clock [get_clocks "clk"] [all_outputs]
set_output_delay -min 0.0 -clock [get_clocks "clk"] [all_outputs]

set_driving_cell -lib_cell BUFX2 [get_ports "rst"]
set_load 0.01 [all_outputs]

set_max_transition 0.5 [current_design]
set_max_fanout     32  [current_design]
