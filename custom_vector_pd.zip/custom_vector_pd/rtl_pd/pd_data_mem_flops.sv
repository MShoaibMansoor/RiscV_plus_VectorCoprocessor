// =============================================================================
// pd_data_mem_flops.sv - PHYSICAL-DESIGN view of `data_mem` for the 45 nm
// gpdk045 flow (no SRAM macro available in that kit).
//
// Same module name / ports as rtl/rv32i_memories.sv, so riscv_soc_top.sv is read
// unchanged. Identical behaviour to the behavioural model (combinational read,
// byte-enable write on posedge) - only the depth is reduced:
//   PD_WORDS x 32 bit (default 256 words = 1 KB), mirrored across 0x0000-0xFFFF.
// Keep program data inside 0x000-0x3FF. Lower PD_WORDS (e.g. 64) to cut runtime.
// =============================================================================
module data_mem #(parameter int WORDS = 16384) (   // WORDS kept for port-compat, unused
    input  logic        clk, memwrite,
    input  logic [3:0]  be,
    input  logic [31:0] A,
    input  logic [31:0] WD,
    output logic [31:0] RD
);
    localparam int PD_WORDS = 256;
    localparam int AW       = $clog2(PD_WORDS);

    logic [31:0]   mem [0:PD_WORDS-1];
    logic [AW-1:0] idx;

    assign idx = A[AW+1:2];
    assign RD  = mem[idx];

    always_ff @(posedge clk)
        if (memwrite) begin
            if (be[0]) mem[idx][7:0]   <= WD[7:0];
            if (be[1]) mem[idx][15:8]  <= WD[15:8];
            if (be[2]) mem[idx][23:16] <= WD[23:16];
            if (be[3]) mem[idx][31:24] <= WD[31:24];
        end
endmodule
