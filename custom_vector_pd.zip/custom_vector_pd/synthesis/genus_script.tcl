# =============================================================================
# genus_script.tcl - Module 1: synthesis of riscv_soc_top (Genus, Stylus UI)
#   cd synthesis ; genus -f genus_script.tcl
# Same structure as the lab counter script.
# =============================================================================
set_db init_lib_search_path ../lib/
set_db init_hdl_search_path {../rtl/ ../rtl_pd/}      ;# ../rtl finds the .svh includes
read_libs slow_vdd1v0_basicCells.lib

# Your RTL, unchanged. rv32i_memories.sv / sgle_cyc_processor.sv are simulation-only
# and are NOT read; rtl_pd/ supplies the physical ins_mem and data_mem.
read_hdl -sv { rv32i_core_modules.sv vec_alu.sv vec_regfile.sv vec_coproc.sv \
               pd_imem_rom.sv pd_data_mem_flops.sv riscv_soc_top.sv }
elaborate riscv_soc_top
check_design -unresolved > reports/check_design_unresolved.rpt
read_sdc ../constraints/riscv_soc_top.sdc

set_db syn_generic_effort medium
set_db syn_map_effort     medium
set_db syn_opt_effort     medium

set_db optimize_constant_0_flops false
set_db optimize_constant_1_flops false
set_db optimize_merge_flops      false

syn_generic
syn_map
syn_opt

#reports
report_power  > reports/report_power.rpt
report_area   > reports/report_area.rpt
report_gates  > reports/report_gates.rpt
report_qor    > reports/report_qor.rpt
write_hdl > outputs/riscv_soc_top_netlist.v
write_sdc > outputs/riscv_soc_top_sdc.sdc
write_sdf -timescale ns -nonegchecks -recrem split -edges check_edge -setuphold split > outputs/delays.sdf
write_do_lec -revised_design outputs/riscv_soc_top_netlist.v > ../Equivalence_checking/rtl2gate_auto.do

#Outputs
write_hdl > outputs/riscv_soc_top_netlist.v
write_sdc > outputs/riscv_soc_top_sdc.sdc
write_sdf -timescale ns -nonegchecks -recrem split -edges check_edge -setuphold split > outputs/delays.sdf
write_do_lec -revised_design outputs/riscv_soc_top_netlist.v > ../Equivalence_checking/rtl2gate_auto.do
