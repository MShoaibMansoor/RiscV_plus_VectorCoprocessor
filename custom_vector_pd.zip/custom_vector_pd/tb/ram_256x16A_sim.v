// =============================================================================
// ram_256x16A_sim.v - SIMPLE behavioural stand-in for the lab SRAM macro, used
// ONLY to simulate rtl_pd/ (RTL-with-PD-memories and gate-level sim).
// Prefer the vendor Verilog model shipped with the macro if your kit has one.
// Synchronous: on the rising edge of CLK with CEN=0, WEN=0 writes D to A,
// WEN=1 reads A into Q. OEN=1 tristates Q.
// =============================================================================
`timescale 1ns/1ps
module ram_256x16A (
    input  wire        CLK, CEN, WEN, OEN,
    input  wire [7:0]  A,
    input  wire [15:0] D,
    output wire [15:0] Q
);
    reg [15:0] mem [0:255];
    reg [15:0] q_r;
    integer k;
    initial for (k = 0; k < 256; k = k + 1) mem[k] = 16'h0000;
    always @(posedge CLK)
        if (!CEN) begin
            if (!WEN) begin mem[A] <= D; q_r <= D; end   // write-through
            else           q_r <= mem[A];
        end
    assign Q = OEN ? 16'hzzzz : q_r;
endmodule
