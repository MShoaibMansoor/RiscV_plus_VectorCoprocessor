# run_questa.do - compile + run both self-checking tests in Questa
#   cd tb ; vsim -c -do run_questa.do
vlib work
# 1) coprocessor unit test (42 checks)
vlog -sv +incdir+../rtl ../rtl/vec_alu.sv ../rtl/vec_regfile.sv ../rtl/vec_coproc.sv tb_vec_coproc.sv
vsim -c tb_vec_coproc -do "run -all; quit -sim"
# 2) full SoC with the SYNTHESIS memories (rtl_pd) running the ROM program
vlog -sv +incdir+../rtl ../rtl/rv32i_core_modules.sv ../rtl/vec_alu.sv ../rtl/vec_regfile.sv \
     ../rtl/vec_coproc.sv ../rtl_pd/pd_imem_rom.sv ../rtl_pd/pd_data_mem_flops.sv \
     ../rtl/riscv_soc_top.sv tb_pd_equiv.sv
vsim -c tb_pd_equiv +TRACE=trace_pd.txt -do "run -all; quit"
