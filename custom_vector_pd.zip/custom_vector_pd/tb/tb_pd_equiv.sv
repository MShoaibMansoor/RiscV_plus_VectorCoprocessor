// =============================================================================
// tb_pd_equiv.sv - proves the PD memory views (rtl_pd/) behave exactly like the
// behavioural memories (rtl/rv32i_memories.sv). Run it twice - once with each
// memory set - and diff the two retire traces (scripts/run_pd_equiv_sim.sh).
// =============================================================================
`timescale 1ns/1ps
`include "rv32i_types.svh"
module tb_pd_equiv;
    logic clk = 0, rst = 1;
    logic trap, halted;
    logic [4:0] trap_cause;
    logic [`RV_RVFI_W-1:0] rvfi_bus;
    rvfi_t t;
    integer fd, cyc;
    logic [8*256-1:0] trace;

    riscv_soc_top dut (.clk(clk), .rst(rst), .trap(trap), .halted(halted),
                       .trap_cause(trap_cause), .rvfi(rvfi_bus));

    always #5 clk = ~clk;
    assign t = rvfi_t'(rvfi_bus);

    initial begin
        if (!$value$plusargs("TRACE=%s", trace)) trace = "trace.txt";
        fd = $fopen(trace, "w");
        #12 rst = 0;
        for (cyc = 0; cyc < 2000 && !halted; cyc = cyc + 1) begin
            @(posedge clk); #1;
        end
        $fclose(fd);
        $display("done after %0d cycles, halted=%0b", cyc, halted);
        $finish;
    end

    always @(posedge clk)          // sample at the end of each instruction (before state updates)
        if (!rst && t.valid)
            $fdisplay(fd, "%0d pc=%08h insn=%08h rd=%0d wd=%08h maddr=%08h wm=%h wdat=%08h rm=%h rdat=%08h trap=%0b",
                      t.order, t.pc_rdata, t.insn, t.rd_addr, t.rd_wdata, t.mem_addr,
                      t.mem_wmask, t.mem_wdata, t.mem_rmask,
                      t.mem_rdata & {{8{t.mem_rmask[3]}},{8{t.mem_rmask[2]}},{8{t.mem_rmask[1]}},{8{t.mem_rmask[0]}}},  // only bytes actually read
                      t.trap);
endmodule
