// ============================================================================
// File: tb_layered_vector_soc.sv
// Description: Class-Based Layered Testbench with Reference Model for QuestaSim
// ============================================================================

`timescale 1ns/1ps

// ----------------------------------------------------------------------------
// 1. Interface Definition
// ----------------------------------------------------------------------------
interface vcop_if (input logic clk, input logic rst_n);
    logic [11:0] addr;
    logic [31:0] wdata;
    logic        wren;
    logic        rden;
    logic [31:0] rdata;

    clocking cb @(posedge clk);
        default input #1ns output #1ns;
        output addr, wdata, wren, rden;
        input  rdata;
    endclocking
endinterface

// ----------------------------------------------------------------------------
// 2. Transaction Packet
// ----------------------------------------------------------------------------
class vcop_transaction;
    rand bit [11:0] addr;
    rand bit [31:0] wdata;
    rand bit        wren;
    rand bit        rden;
    bit      [31:0] rdata;

    function void display(string prefix="TX");
        $display("[%s] t=%0t ns | Addr=0x%3h | WData=0x%8h | WEn=%0b | REn=%0b | RData=0x%8h", 
                 prefix, $time, addr, wdata, wren, rden, rdata);
    endfunction
endclass

// ----------------------------------------------------------------------------
// 3. Driver Component
// ----------------------------------------------------------------------------
class vcop_driver;
    virtual vcop_if vif;
    mailbox #(vcop_transaction) gen2drv;

    function new(virtual vcop_if vif, mailbox #(vcop_transaction) gen2drv);
        this.vif     = vif;
        this.gen2drv = gen2drv;
    endfunction

    task run();
        vcop_transaction tx;
        forever begin
            gen2drv.get(tx);
            @(vif.cb);
            vif.cb.addr  <= tx.addr;
            vif.cb.wdata <= tx.wdata;
            vif.cb.wren  <= tx.wren;
            vif.cb.rden  <= tx.rden;
            @(vif.cb);
            vif.cb.wren  <= 1'b0;
            vif.cb.rden  <= 1'b0;
        end
    endtask
endclass

//// ----------------------------------------------------------------------------
//// 4. Monitor Component
//// ----------------------------------------------------------------------------
//class vcop_monitor;
//    virtual vcop_if vif;
//    mailbox #(vcop_transaction) mon2scb;
//
//    function new(virtual vcop_if vif, mailbox #(vcop_transaction) mon2scb);
//        this.vif     = vif;
//        this.mon2scb = mon2scb;
//    endfunction
//
//    task run();
//        forever begin
//            @(vif.cb);
//            if (vif.cb.wren || vif.cb.rden) begin
//                vcop_transaction tx = new();
//                tx.addr  = vif.cb.addr;
//                tx.wdata = vif.cb.wdata;
//                tx.wren  = vif.cb.wren;
//                tx.rden  = vif.cb.rden;
////                #1ns;
//                tx.rdata = vif.rdata; // Sample read data while bus controls are active
//                mon2scb.put(tx);
//		@(vif.cb); // Wait for driver to clear wren/rden to avoid double sampling
//            end
//        end
//    endtask
// ----------------------------------------------------------------------------
// 4. Monitor Component (Fixed Clocking & Sampling)
// ----------------------------------------------------------------------------
class vcop_monitor;
    virtual vcop_if vif;
    mailbox #(vcop_transaction) mon2scb;

    function new(virtual vcop_if vif, mailbox #(vcop_transaction) mon2scb);
        this.vif     = vif;
        this.mon2scb = mon2scb;
    endfunction

    task run();
        forever begin
            @(posedge vif.clk);
            if (vif.wren || vif.rden) begin
                vcop_transaction tx = new();
                tx.addr  = vif.addr;
                tx.wdata = vif.wdata;
                tx.wren  = vif.wren;
                tx.rden  = vif.rden;
                tx.rdata = vif.rdata; // Sample live bus data at posedge clk
                mon2scb.put(tx);
            end
        end
    endtask
endclass

// ----------------------------------------------------------------------------
// 5. Scoreboard & Golden Reference Model
// ----------------------------------------------------------------------------
class vcop_scoreboard;
    mailbox #(vcop_transaction) mon2scb;

    // Shadow Memory for Reference Verification
    bit [31:0] shadow_vreg [0:7][0:7];
    int match_count = 0;
    int error_count = 0;

    function new(mailbox #(vcop_transaction) mon2scb);
        this.mon2scb = mon2scb;
        foreach (shadow_vreg[i, j]) shadow_vreg[i][j] = '0;
    endfunction

    task run();
        vcop_transaction tx;
        forever begin
            mon2scb.get(tx);
            
            // Track Writes to Shadow Vector Registers
            if (tx.wren && (tx.addr >= 12'h100) && (tx.addr <= 12'h1FF)) begin
                bit [5:0] index = (tx.addr - 12'h100) >> 2;
                shadow_vreg[index[5:3]][index[2:0]] = tx.wdata;
            end

            // Verify Read Operations
            if (tx.rden && (tx.addr >= 12'h100) && (tx.addr <= 12'h1FF)) begin
                bit [5:0] index = (tx.addr - 12'h100) >> 2;
                bit [31:0] expected = shadow_vreg[index[5:3]][index[2:0]];
                if (tx.rdata === expected) begin
                    $display("[SCB SUCCESS] Read Addr=0x%3h | Actual=0x%8h | Expected=0x%8h", tx.addr, tx.rdata, expected);
                    match_count++;
                end else begin
                    $error("[SCB MISMATCH] Read Addr=0x%3h | Actual=0x%8h | Expected=0x%8h", tx.addr, tx.rdata, expected);
                    error_count++;
                end
            end
        end
    endtask

    // Reference Compute Engine for Direct Verification
    function void execute_reference_cmd(bit [2:0] op, bit [2:0] s1, bit [2:0] s2, bit [2:0] dst, bit [3:0] vlen);
        if (op > 3 || vlen == 0 || vlen > 8) begin
            $display("[SCB REF] Recognized expected invalid command trigger.");
            return;
        end

        case (op)
            3'd0: for (int i=0; i<vlen; i++) shadow_vreg[dst][i] = shadow_vreg[s1][i] + shadow_vreg[s2][i];
            3'd1: for (int i=0; i<vlen; i++) shadow_vreg[dst][i] = shadow_vreg[s1][i] * shadow_vreg[s2][i];
            3'd2: for (int i=0; i<vlen; i++) shadow_vreg[dst][i] = (shadow_vreg[s1][i] > shadow_vreg[s2][i]) ? 32'd1 : 32'd0;
            3'd3: begin
                bit [31:0] sum = 0;
                for (int i=0; i<vlen; i++) sum += shadow_vreg[s1][i];
                shadow_vreg[dst][0] = sum;
            end
        endcase
    endfunction
endclass

// ----------------------------------------------------------------------------
// 6. Environment Wrapper
// ----------------------------------------------------------------------------
class vcop_env;
    vcop_driver     drv;
    vcop_monitor    mon;
    vcop_scoreboard scb;
    
    mailbox #(vcop_transaction) gen2drv;
    mailbox #(vcop_transaction) mon2scb;
    
    virtual vcop_if vif;

    function new(virtual vcop_if vif);
        this.vif     = vif;
        gen2drv      = new();
        mon2scb      = new();
        drv          = new(vif, gen2drv);
        mon          = new(vif, mon2scb);
        scb          = new(mon2scb);
    endfunction

    task run();
        fork
            drv.run();
            mon.run();
            scb.run();
        join_none
    endtask
endclass

// ----------------------------------------------------------------------------
// 7. Top-Level Verification Module
// ----------------------------------------------------------------------------
//module tb_top;
//    logic clk;
//    logic rst_n;
//
//    // Clock Generation (100 MHz)
//    initial clk = 0;
//    always #5ns clk = ~clk;
//
//    // Interface Instantiation
//    vcop_if vif(clk, rst_n);
//
//    // DUT Instantiation
//    vector_coproc #(
//        .VLEN_WORDS(8),
//        .VREG_NUM(8)
//    ) dut (
//        .clk   (clk),
//        .rst_n (rst_n),
//        .addr  (vif.addr),
//        .wdata (vif.wdata),
//        .wren  (vif.wren),
//        .rden  (vif.rden),
//        .rdata (vif.rdata)
//    );
//
//    vcop_env env;
//
////    // Helper Task: Send Bus Transaction
////    task automatic send_tx(bit [11:0] addr, bit [31:0] wdata, bit wren, bit rden);
////        vcop_transaction tx = new();
////        tx.addr  = addr;
////        tx.wdata = wdata;
////        tx.wren  = wren;
////        tx.rden  = rden;
////        env.gen2drv.put(tx);
////        #20ns;
////    endtask
////
////    // Helper Task: Poll Status Register
////    task automatic poll_until_done();
////        bit [31:0] status;
////        do begin
////            send_tx(12'h004, 32'h0, 1'b0, 1'b1);
////            #10ns;
////            status = vif.rdata;
////        end while (status[0] == 1'b1); // While Busy
////    endtask
//
//// Helper Task: Explicit Read Bus Transaction
//    task automatic read_tx(bit [11:0] addr, output bit [31:0] rdata);
//        vcop_transaction tx = new();
//        tx.addr  = addr;
//        tx.wdata = 32'h0;
//        tx.wren  = 1'b0;
//        tx.rden  = 1'b1;
//        env.gen2drv.put(tx);
//        #10ns;             // Wait 1 cycle for driver execution
//        rdata = vif.rdata; // Capture bus data while rden is active
//        #10ns;
//    endtask
//
//    // Helper Task: Fixed Status Polling
//    task automatic poll_until_done();
//        bit [31:0] status;
//        do begin
//            read_tx(12'h004, status);
//        end while (status[0] == 1'b1); // Poll while busy bit is high
//    endtask
//
//    // Directed Verification Stimulus
//    initial begin
//        rst_n = 0;
//        env   = new(vif);
//        env.run();
//
//        $display("==================================================");
//        $display("   TEST 1: Hardware Reset Verification           ");
//        $display("==================================================");
//        #20ns;
//        rst_n = 1;
//        #10ns;
//        
//        // Read Status directly after reset
////        send_tx(12'h004, 32'h0, 1'b0, 1'b1);
////        $display("[RESET CHECK] Status Register = 0x%8h (Expected 0x0)", vif.rdata);
//	// TEST 1: Read Status directly after reset
//        bit [31:0] status_val;
//        read_tx(12'h004, status_val);
//        $display("[RESET CHECK] Status Register = 0x%8h (Expected 0x0)", status_val);
//
//
//        $display("==================================================");
//        $display("   TEST 2: Load Operands into VREG0 & VREG1       ");
//        $display("==================================================");
//        for (int i = 0; i < 8; i++) begin
//            send_tx(12'h100 + (i*4), (i + 1) * 10, 1'b1, 1'b0); // VREG0[i] = 10, 20, 30...
//            send_tx(12'h120 + (i*4), (i + 1) * 2,  1'b1, 1'b0); // VREG1[i] = 2, 4, 6...
//        end
//
//        $display("==================================================");
//        $display("   TEST 3: Vector Execution - ADD (VREG2 = VREG0 + VREG1)");
//        $display("==================================================");
//        // VCMD: Opcode=0 (ADD), Src1=0, Src2=1, Dst=2, VLEN=8 -> 0x8400
//        send_tx(12'h000, 32'h0000_8400, 1'b1, 1'b0);
//        env.scb.execute_reference_cmd(3'd0, 3'd0, 3'd1, 3'd2, 4'd8);
//        poll_until_done();
//
//        // Verify Results
//        for (int i = 0; i < 8; i++) begin
//            send_tx(12'h140 + (i*4), 32'h0, 1'b0, 1'b1);
//        end
//
//        $display("==================================================");
//        $display("   TEST 4: Vector Execution - MUL (VREG3 = VREG0 * VREG1)");
//        $display("==================================================");
//        // VCMD: Opcode=1 (MUL), Src1=0, Src2=1, Dst=3, VLEN=8 -> 0x8609
//        send_tx(12'h000, 32'h0000_8609, 1'b1, 1'b0);
//        env.scb.execute_reference_cmd(3'd1, 3'd0, 3'd1, 3'd3, 4'd8);
//        poll_until_done();
//
//        for (int i = 0; i < 8; i++) begin
//            send_tx(12'h160 + (i*4), 32'h0, 1'b0, 1'b1);
//        end
//
//        $display("==================================================");
//        $display("   TEST 5: Vector Execution - REDSUM (VREG4[0] = Sum(VREG0))");
//        $display("==================================================");
//        // VCMD: Opcode=3 (REDSUM), Src1=0, Src2=0, Dst=4, VLEN=8 -> 0x8803
//        send_tx(12'h000, 32'h0000_8803, 1'b1, 1'b0);
//        env.scb.execute_reference_cmd(3'd3, 3'd0, 3'd0, 3'd4, 4'd8);
//        poll_until_done();
//
//        // Read Result Word 0
//        send_tx(12'h180, 32'h0, 1'b0, 1'b1);
//
//        $display("==================================================");
//        $display("   TEST 6: Invalid Command Error Case (Opcode = 5)");
//        $display("==================================================");
//        // Invalid Opcode 5
//        send_tx(12'h000, 32'h0000_8805, 1'b1, 1'b0);
//        #20ns;
////        send_tx(12'h004, 32'h0, 1'b0, 1'b1);
////        $display("[ERROR CHECK] Status Register = 0x%8h (Bit 2 Error Expected)", vif.rdata);
//	read_tx(12'h004, status_val);
//        $display("[ERROR CHECK] Status Register = 0x%8h (Bit 2 Error Expected)", status_val);
//
//        $display("==================================================");
//        $display("   VERIFICATION SUMMARY                          ");
//        $display("==================================================");
//        $display(" Total Matches: %0d", env.scb.match_count);
//        $display(" Total Errors : %0d", env.scb.error_count);
//        
//        if (env.scb.error_count == 0)
//            $display(" STATUS: TEST PASSED SUCCESSFULLY!");
//        else
//            $display(" STATUS: TEST FAILED!");
//
//        $finish;
//    end
//endmodule


// ----------------------------------------------------------------------------
// 7. Top-Level Verification Module
// ----------------------------------------------------------------------------
module tb_top;
    logic clk;
    logic rst_n;

    // Clock Generation (100 MHz)
    initial clk = 0;
    always #5ns clk = ~clk;

    // Interface Instantiation
    vcop_if vif(clk, rst_n);

    // DUT Instantiation
    vector_coproc #(
        .VLEN_WORDS(8),
        .VREG_NUM(8)
    ) dut (
        .clk   (clk),
        .rst_n (rst_n),
        .addr  (vif.addr),
        .wdata (vif.wdata),
        .wren  (vif.wren),
        .rden  (vif.rden),
        .rdata (vif.rdata)
    );

    vcop_env env;

    // Helper Task: Send Bus Transaction (Write / Standard)
    task automatic send_tx(bit [11:0] addr, bit [31:0] wdata, bit wren, bit rden);
        vcop_transaction tx = new();
        tx.addr  = addr;
        tx.wdata = wdata;
        tx.wren  = wren;
        tx.rden  = rden;
        env.gen2drv.put(tx);
        #20ns;
    endtask

    // Helper Task: Explicit Read Bus Transaction
    task automatic read_tx(bit [11:0] addr, output bit [31:0] rdata);
        vcop_transaction tx = new();
        tx.addr  = addr;
        tx.wdata = 32'h0;
        tx.wren  = 1'b0;
        tx.rden  = 1'b1;
        env.gen2drv.put(tx);
        #10ns;             // Wait 1 cycle for driver execution
        rdata = vif.rdata; // Capture bus data while rden is active
        #10ns;
    endtask

    // Helper Task: Fixed Status Polling
    task automatic poll_until_done();
        bit [31:0] status;
        do begin
            read_tx(12'h004, status);
        end while (status[0] == 1'b1); // Poll while busy bit is high
    endtask

    // Directed Verification Stimulus
    initial begin
        // Variable declarations MUST precede procedural statements
        bit [31:0] status_val;

        rst_n = 0;
        env   = new(vif);
        env.run();

        $display("==================================================");
        $display("   TEST 1: Hardware Reset Verification           ");
        $display("==================================================");
        #20ns;
        rst_n = 1;
        #10ns;
        
        // TEST 1: Read Status directly after reset
        read_tx(12'h004, status_val);
        $display("[RESET CHECK] Status Register = 0x%8h (Expected 0x0)", status_val);

        $display("==================================================");
        $display("   TEST 2: Load Operands into VREG0 & VREG1       ");
        $display("==================================================");
        for (int i = 0; i < 8; i++) begin
            send_tx(12'h100 + (i*4), (i + 1) * 10, 1'b1, 1'b0); // VREG0[i] = 10, 20, 30...
            send_tx(12'h120 + (i*4), (i + 1) * 2,  1'b1, 1'b0); // VREG1[i] = 2, 4, 6...
        end

        $display("==================================================");
        $display("   TEST 3: Vector Execution - ADD (VREG2 = VREG0 + VREG1)");
        $display("==================================================");
        // VCMD: Opcode=0 (ADD), Src1=0, Src2=1, Dst=2, VLEN=8 -> 0x8400
        send_tx(12'h000, 32'h0000_8400, 1'b1, 1'b0);
        env.scb.execute_reference_cmd(3'd0, 3'd0, 3'd1, 3'd2, 4'd8);
        poll_until_done();

        // Verify Results
        for (int i = 0; i < 8; i++) begin
            send_tx(12'h140 + (i*4), 32'h0, 1'b0, 1'b1);
        end

        $display("==================================================");
        $display("   TEST 4: Vector Execution - MUL (VREG3 = VREG0 * VREG1)");
        $display("==================================================");
        // VCMD: Opcode=1 (MUL), Src1=0, Src2=1, Dst=3, VLEN=8 -> 0x8609
        send_tx(12'h000, 32'h0000_8609, 1'b1, 1'b0);
        env.scb.execute_reference_cmd(3'd1, 3'd0, 3'd1, 3'd3, 4'd8);
        poll_until_done();

        for (int i = 0; i < 8; i++) begin
            send_tx(12'h160 + (i*4), 32'h0, 1'b0, 1'b1);
        end

        $display("==================================================");
        $display("   TEST 5: Vector Execution - REDSUM (VREG4[0] = Sum(VREG0))");
        $display("==================================================");
        // VCMD: Opcode=3 (REDSUM), Src1=0, Src2=0, Dst=4, VLEN=8 -> 0x8803
        send_tx(12'h000, 32'h0000_8803, 1'b1, 1'b0);
        env.scb.execute_reference_cmd(3'd3, 3'd0, 3'd0, 3'd4, 4'd8);
        poll_until_done();

        // Read Result Word 0
        send_tx(12'h180, 32'h0, 1'b0, 1'b1);

        $display("==================================================");
        $display("   TEST 6: Invalid Command Error Case (Opcode = 5)");
        $display("==================================================");
        // Invalid Opcode 5
        send_tx(12'h000, 32'h0000_8805, 1'b1, 1'b0);
        #20ns;
        read_tx(12'h004, status_val);
        $display("[ERROR CHECK] Status Register = 0x%8h (Bit 2 Error Expected)", status_val);

        $display("==================================================");
        $display("   VERIFICATION SUMMARY                          ");
        $display("==================================================");
        $display(" Total Matches: %0d", env.scb.match_count);
        $display(" Total Errors : %0d", env.scb.error_count);
        
        if (env.scb.error_count == 0)
            $display(" STATUS: TEST PASSED SUCCESSFULLY!");
        else
            $display(" STATUS: TEST FAILED!");

        $finish;
    end
endmodule