// ============================================================================
// File: tb_soc_layered.sv
// Description: Layered Testbench for RV32I SoC Top
// ============================================================================

`timescale 1ns/1ps

// ----------------------------------------------------------------------------
// 1. Interface Definition
// ----------------------------------------------------------------------------
// The interface connects the testbench components to the DUT's internal bus
interface soc_if(input logic clk);
    logic        rst_n;
    logic [31:0] mem_addr;
    logic [31:0] mem_wdata;
    logic        mem_we;
endinterface

// ----------------------------------------------------------------------------
// 2. Transaction Packet
// ----------------------------------------------------------------------------
// Represents a memory write operation performed by the CPU
class soc_transaction;
    bit [31:0] addr;
    bit [31:0] data;

    function new(bit [31:0] a = 0, bit [31:0] d = 0);
        this.addr = a;
        this.data = d;
    endfunction

    function void display(string prefix="TX");
        $display("[%s] Time: %0t | Addr: 0x%08h | Data: 0x%08h", prefix, $time, addr, data);
    endfunction
endclass

// ----------------------------------------------------------------------------
// 3. Generator Component
// ----------------------------------------------------------------------------
// Feeds the expected memory transactions to the scoreboard based on the test program
class soc_generator;
    mailbox #(soc_transaction) expected_mbx;

    function new(mailbox #(soc_transaction) mbx);
        this.expected_mbx = mbx;
    endfunction

    task run();
        soc_transaction tx1, tx2;
        
        // Based on our RISC-V test program, we expect two memory writes:
        // 1. SW x3, 0(x4) -> Write 0x0000001E (30) to DMEM at 0x00002000
        tx1 = new(32'h0000_2000, 32'h0000_001E);
        expected_mbx.put(tx1);

        // 2. SW x3, 0(x5) -> Write 0x0000001E (30) to MMIO Vector Coprocessor at 0x8000_0000
        tx2 = new(32'h8000_0000, 32'h0000_001E);
        expected_mbx.put(tx2);
    endtask
endclass

// ----------------------------------------------------------------------------
// 4. Driver Component
// ----------------------------------------------------------------------------
// Handles the hardware reset sequence to start the CPU
class soc_driver;
    virtual soc_if vif;

    function new(virtual soc_if vif);
        this.vif = vif;
    endfunction

    task run();
        $display("[DRIVER] Asserting Reset...");
        vif.rst_n = 1'b0;
        #20ns;
        vif.rst_n = 1'b1;
        $display("[DRIVER] Reset Released. CPU Booting...");
    endtask
endclass

// ----------------------------------------------------------------------------
// 5. Monitor Component
// ----------------------------------------------------------------------------
// Passively snoops the memory bus and captures writes
class soc_monitor;
    virtual soc_if vif;
    mailbox #(soc_transaction) actual_mbx;

    function new(virtual soc_if vif, mailbox #(soc_transaction) mbx);
        this.vif = vif;
        this.actual_mbx = mbx;
    endfunction

    task run();
        forever begin
            @(posedge vif.clk);
            if (vif.rst_n && vif.mem_we) begin
                soc_transaction tx = new(vif.mem_addr, vif.mem_wdata);
                tx.display("MONITOR");
                actual_mbx.put(tx);
            end
        end
    endtask
endclass

// ----------------------------------------------------------------------------
// 6. Scoreboard Component
// ----------------------------------------------------------------------------
// Compares captured transactions against expected transactions
class soc_scoreboard;
    mailbox #(soc_transaction) expected_mbx;
    mailbox #(soc_transaction) actual_mbx;
    event test_done;
    
    int match_count = 0;
    int expected_total = 2; // We expect exactly 2 writes

    function new(mailbox #(soc_transaction) e_mbx, mailbox #(soc_transaction) a_mbx, event done_evt);
        this.expected_mbx = e_mbx;
        this.actual_mbx   = a_mbx;
        this.test_done    = done_evt;
    endfunction

    task run();
        soc_transaction exp_tx, act_tx;
        forever begin
            actual_mbx.get(act_tx);
            expected_mbx.get(exp_tx);

            if (act_tx.addr == exp_tx.addr && act_tx.data == exp_tx.data) begin
                $display("[SCOREBOARD] SUCCESS: Matched Addr=0x%08h, Data=0x%08h", act_tx.addr, act_tx.data);
                match_count++;
            end else begin
                $error("[SCOREBOARD] MISMATCH! Expected: Addr=0x%08h Data=0x%08h | Actual: Addr=0x%08h Data=0x%08h",
                        exp_tx.addr, exp_tx.data, act_tx.addr, act_tx.data);
            end

            if (match_count == expected_total) begin
                $display("[SCOREBOARD] All expected transactions verified.");
                -> test_done; // Trigger end of simulation
            end
        end
    endtask
endclass

// ----------------------------------------------------------------------------
// 7. Environment Component
// ----------------------------------------------------------------------------
class soc_env;
    soc_generator  gen;
    soc_driver     drv;
    soc_monitor    mon;
    soc_scoreboard scb;

    mailbox #(soc_transaction) expected_mbx;
    mailbox #(soc_transaction) actual_mbx;
    event test_done;

    virtual soc_if vif;

    function new(virtual soc_if vif);
        this.vif = vif;
        expected_mbx = new();
        actual_mbx   = new();
        
        gen = new(expected_mbx);
        drv = new(vif);
        mon = new(vif, actual_mbx);
        scb = new(expected_mbx, actual_mbx, test_done);
    endfunction

    task run();
        fork
            gen.run();
            drv.run();
            mon.run();
            scb.run();
        join_none
        
        // Wait for scoreboard to signal completion
        @test_done;
        $display("==================================================");
        $display(" STATUS: SIMULATION PASSED SUCCESSFULLY!");
        $display("==================================================");
        $finish;
    endtask
endclass

// ----------------------------------------------------------------------------
// 8. Top-Level Verification Module
// ----------------------------------------------------------------------------
module tb_soc_layered;
    logic clk;

    // Clock Generation
    initial clk = 0;
    always #5ns clk = ~clk;

    // Interface Instantiation
    soc_if vif(clk);

    // DUT Instantiation
    soc_top dut (
        .clk            (clk),
        .rst_n          (vif.rst_n),
        .current_pc     (),
        .last_mem_rdata ()
    );

    // Bind internal DUT signals to the interface for the Monitor to snoop
    assign vif.mem_addr  = dut.core_mem_addr;
    assign vif.mem_wdata = dut.core_mem_wdata;
    assign vif.mem_we    = dut.core_mem_we;

    soc_env env;

    // Program Generation & Simulation Execution
//    initial begin
//        int fd;
//        
//        // Step 1: Dynamically generate a RISC-V hex program for testing.
//        // This avoids needing a separate assembler/compiler setup.
//        fd = $fopen("program.hex", "w");
//        
//        // Program Logic:
//        // x1 = 10; x2 = 20; x3 = x1 + x2 (30)
//        // Store x3 to DMEM (0x00002000)
//        // Store x3 to VCOP (0x80000000)
//        
//        $fdisplay(fd, "00a00093"); // [0x00] addi x1, x0, 10
//        $fdisplay(fd, "01400113"); // [0x04] addi x2, x0, 20
//        $fdisplay(fd, "002081b3"); // [0x08] add  x3, x1, x2
//        $fdisplay(fd, "00002237"); // [0x0C] lui  x4, 0x2 (x4 = 0x00002000)
//        $fdisplay(fd, "00322023"); // [0x10] sw   x3, 0(x4)  -> EXPECTED WRITE 1
//        $fdisplay(fd, "800002b7"); // [0x14] lui  x5, 0x80000 (x5 = 0x80000000)
//        $fdisplay(fd, "0032a023"); // [0x18] sw   x3, 0(x5)  -> EXPECTED WRITE 2
//        $fdisplay(fd, "0000006f"); // [0x1C] j    0 (infinite loop, pc stays here)
//        $fclose(fd);
//        
//        $display("[TB] Generated program.hex successfully.");
//
//        // Step 2: Initialize and run environment
//        env = new(vif);
//        env.run();
//        
//        // Failsafe timeout in case CPU gets stuck
//        #500ns;
//        $display("[TB] ERROR: Simulation Timeout!");
//        $finish;
//    end


// Program Generation & Simulation Execution
    initial begin
        // REMOVED the $fopen and $fdisplay file generation block
        
        $display("[TB] Using external program.hex file.");

        // Initialize and run environment
        env = new(vif);
        env.run();
        
        // Failsafe timeout in case CPU gets stuck
        #500ns;
        $display("[TB] ERROR: Simulation Timeout!");
        $finish;
    end
endmodule